<footer class="footer">
      <div class="footer-container">
        <div class="copyright">
          <i class="far fa-copyright"></i>
          2023 Solar Energy Solutions. All rights reserved.
        </div>

        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <span class="separator">|</span>
          <a href="#">Terms of Service</a>
        </div>
      </div>
    </footer>