<h4>Step 2: Communication & Address Details</h4>
<form id="step2Form" method="POST" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">District</label>
            <input type="text" class="form-control" name="district" value="<?php echo htmlspecialchars($client_data['district'] ?? ''); ?>">
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Block</label>
            <input type="text" class="form-control" name="block" value="<?php echo htmlspecialchars($client_data['block'] ?? ''); ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Taluka</label>
            <input type="text" class="form-control" name="taluka" value="<?php echo htmlspecialchars($client_data['taluka'] ?? ''); ?>">
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Village</label>
            <input type="text" class="form-control" name="village" value="<?php echo htmlspecialchars($client_data['village'] ?? ''); ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Customer Mobile Number *</label>
            <input type="tel" class="form-control" name="mobile" value="<?php echo htmlspecialchars($client_data['mobile'] ?? ''); ?>" required>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($client_data['email'] ?? ''); ?>">
        </div>
    </div>
</form>