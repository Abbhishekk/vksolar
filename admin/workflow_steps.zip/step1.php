<h4>Step 1: Basic Details</h4>
<form id="step1Form" method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label class="form-label">Name of Customer *</label>
        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($client_data['name'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Consumer Number *</label>
        <input type="text" class="form-control" name="consumer_number" value="<?php echo htmlspecialchars($client_data['consumer_number'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Billing Unit</label>
        <input type="text" class="form-control" name="billing_unit" value="<?php echo htmlspecialchars($client_data['billing_unit'] ?? ''); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Location URL</label>
        <input type="url" class="form-control" name="location_url" value="<?php echo htmlspecialchars($client_data['location'] ?? ''); ?>" placeholder="https://maps.google.com/...">
    </div>
</form>