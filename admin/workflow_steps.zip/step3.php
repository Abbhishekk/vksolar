<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 3: MAHADISCOM Email & Mobile Update</h5>
    </div>
    <div class="card-body">
        <form id="step3Form">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="mahadiscom_email" 
                           value="<?php echo $client_data['mahadiscom_email'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email Password</label>
                    <input type="text" class="form-control" name="mahadiscom_email_password" 
                           value="<?php echo $client_data['mahadiscom_email_password'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Mobile</label>
                    <input type="text" class="form-control" name="mahadiscom_mobile" 
                           value="<?php echo $client_data['mahadiscom_mobile'] ?? ''; ?>">
                </div>
            </div>
        </form>
    </div>
</div>