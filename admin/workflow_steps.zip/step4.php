<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 4: MAHADISCOM Registration</h5>
    </div>
    <div class="card-body">
        <form id="step4Form">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">User ID</label>
                    <input type="text" class="form-control" name="mahadiscom_user_id" 
                           value="<?php echo $client_data['mahadiscom_user_id'] ?? ''; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="mahadiscom_password" 
                           value="<?php echo $client_data['mahadiscom_password'] ?? ''; ?>">
                </div>
            </div>
        </form>
    </div>
</div>