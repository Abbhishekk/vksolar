<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 14: Reference Details</h5>
    </div>
    <div class="card-body">
        <form id="step14Form">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reference Name</label>
                    <input type="text" class="form-control" name="reference_name" 
                           value="<?php echo htmlspecialchars($client_data['reference_name'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reference Contact</label>
                    <input type="text" class="form-control" name="reference_contact" 
                           value="<?php echo htmlspecialchars($client_data['reference_contact'] ?? ''); ?>">
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function validateStep14() {
    // Reference fields are optional
    return true;
}
</script>