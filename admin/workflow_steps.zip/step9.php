<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 9: Fitting Photos</h5>
    </div>
    <div class="card-body">
        <form id="step9Form" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Solar Panel Structure Photo</label>
                    <input type="file" class="form-control" name="solar_panel_photo" accept="image/*">
                    <?php if(isset($client_data['solar_panel_photo'])): ?>
                        <small class="text-muted">Current: <?php echo htmlspecialchars($client_data['solar_panel_photo']); ?></small>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Inverter Photo</label>
                    <input type="file" class="form-control" name="inverter_photo" accept="image/*">
                    <?php if(isset($client_data['inverter_photo'])): ?>
                        <small class="text-muted">Current: <?php echo htmlspecialchars($client_data['inverter_photo']); ?></small>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Geotag Photo</label>
                    <input type="file" class="form-control" name="geotag_photo" accept="image/*">
                    <?php if(isset($client_data['geotag_photo'])): ?>
                        <small class="text-muted">Current: <?php echo htmlspecialchars($client_data['geotag_photo']); ?></small>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function validateStep9() {
    // Photo uploads are optional
    return true;
}
</script>