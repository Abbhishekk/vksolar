<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 10: PM SuryaGhar Document Upload</h5>
        <p class="text-muted mb-0">Maximum file size: 5MB per document | Allowed formats: PDF, JPG, JPEG, PNG</p>
    </div>
    <div class="card-body">
        <form id="step10Form" enctype="multipart/form-data">
            
            <!-- Document Uploads Section -->
            <div class="row">
                <div class="col-12 mb-4">
                    <h6 class="border-bottom pb-2">Required Documents</h6>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Aadhar Card <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="aadhar_card" accept=".pdf,.jpg,.jpeg,.png" required>
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">PAN Card <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="pan_card" accept=".pdf,.jpg,.jpeg,.png" required>
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Electricity Bill <span class="form-label">*</span></label>
                    <input type="file" class="form-control" name="electric_bill" accept=".pdf,.jpg,.jpeg,.png" required>
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Bank Passbook/Statement <span class="text-danger">*</span></label>
                    <input type="file" class="form-control" name="bank_passbook" accept=".pdf,.jpg,.jpeg,.png" required>
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
            </div>

            <!-- Optional Documents -->
            <div class="row mt-4">
                <div class="col-12 mb-3">
                    <h6 class="border-bottom pb-2">Additional Documents (Optional)</h6>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Model Agreement</label>
                    <input type="file" class="form-control" name="model_agreement" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">DCR Certificate</label>
                    <input type="file" class="form-control" name="dcr_certificate" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Bank Statement</label>
                    <input type="file" class="form-control" name="bank_statement" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Salary Slip</label>
                    <input type="file" class="form-control" name="salary_slip" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">IT Return</label>
                    <input type="file" class="form-control" name="it_return" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Gumasta License</label>
                    <input type="file" class="form-control" name="gumasta" accept=".pdf,.jpg,.jpeg,.png">
                    <small class="text-muted">PDF, JPG, PNG (Max 5MB)</small>
                </div>
            </div>

            <!-- Inverter & System Details -->
            <div class="row mt-4">
                <div class="col-12 mb-3">
                    <h6 class="border-bottom pb-2">System Details <span class="text-danger">*</span></h6>
                </div>
                
                <div class="col-md-4 mb-3">
                    <label class="form-label">Inverter Manufacturing Company <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="inverter_company_name" 
                           value="<?php echo htmlspecialchars($client_data['inverter_company_name'] ?? ''); ?>" required>
                </div>
                
                <div class="col-md-4 mb-3">
                    <label class="form-label">Inverter Serial Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="inverter_serial_number" 
                           value="<?php echo htmlspecialchars($client_data['inverter_serial_number'] ?? ''); ?>" required>
                </div>
                
                <div class="col-md-4 mb-3">
                    <label class="form-label">DCR Certificate Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="dcr_certificate_number" 
                           value="<?php echo htmlspecialchars($client_data['dcr_certificate_number'] ?? ''); ?>" required>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Number of Solar Panels <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" name="number_of_panels" id="numberOfPanels" 
                           value="<?php echo htmlspecialchars($client_data['number_of_panels'] ?? ''); ?>" min="1" max="20" required>
                </div>
            </div>

            <!-- Dynamic Panel Serial Numbers -->
            <div class="row mt-3">
                <div class="col-12 mb-3">
                    <button type="button" class="btn btn-outline-primary" onclick="generatePanelFields()">
                        <i class="bi bi-plus-circle"></i> Generate Panel Serial Number Fields
                    </button>
                </div>
                
                <div id="panelSerialNumbers" class="col-12">
                    <!-- Dynamic panel serial number fields will be generated here -->
                </div>
            </div>

            <!-- File Upload Progress -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i>
                        <strong>Note:</strong> Required documents must be uploaded. File size should not exceed 5MB per document.
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<script>
function generatePanelFields() {
    const numberOfPanels = parseInt(document.getElementById('numberOfPanels').value) || 0;
    const container = document.getElementById('panelSerialNumbers');
    
    if (numberOfPanels <= 0 || numberOfPanels > 20) {
        alert('Please enter a valid number of panels (1-20)');
        return;
    }
    
    let html = '<div class="row"><div class="col-12"><h6>Panel Serial Numbers <span class="text-danger">*</span></h6></div></div>';
    
    for (let i = 1; i <= numberOfPanels; i++) {
        html += `
            <div class="row mb-2">
                <div class="col-md-6">
                    <label class="form-label">Panel ${i} Serial Number</label>
                    <input type="text" class="form-control" name="panel_serial_${i}" 
                           placeholder="Enter serial number for panel ${i}" required>
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function validateStep10() {
    // Validate required fields
    const requiredFields = [
        'inverter_company_name',
        'inverter_serial_number', 
        'dcr_certificate_number',
        'number_of_panels'
    ];
    
    for (let field of requiredFields) {
        const value = document.querySelector(`[name="${field}"]`).value.trim();
        if (!value) {
            alert(`Please fill in ${field.replace(/_/g, ' ')}`);
            document.querySelector(`[name="${field}"]`).focus();
            return false;
        }
    }
    
    // Validate file inputs
    const requiredFiles = [
        'aadhar_card',
        'pan_card',
        'electric_bill',
        'bank_passbook'
    ];
    
    for (let fileField of requiredFiles) {
        const fileInput = document.querySelector(`[name="${fileField}"]`);
        if (!fileInput.files || fileInput.files.length === 0) {
            alert(`Please upload ${fileField.replace(/_/g, ' ')}`);
            fileInput.focus();
            return false;
        }
        
        // Check file size (5MB = 5 * 1024 * 1024 bytes)
        const file = fileInput.files[0];
        if (file.size > 5242880) {
            alert(`File too large for ${fileField.replace(/_/g, ' ')}. Maximum size is 5MB.`);
            fileInput.focus();
            return false;
        }
        
        // Check file type
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
            alert(`Invalid file type for ${fileField.replace(/_/g, ' ')}. Please upload PDF, JPG, or PNG files only.`);
            fileInput.focus();
            return false;
        }
    }
    
    // Validate panel serial numbers if generated
    const numberOfPanels = parseInt(document.getElementById('numberOfPanels').value) || 0;
    if (numberOfPanels > 0) {
        for (let i = 1; i <= numberOfPanels; i++) {
            const panelSerial = document.querySelector(`[name="panel_serial_${i}"]`);
            if (panelSerial && !panelSerial.value.trim()) {
                alert(`Please enter serial number for panel ${i}`);
                panelSerial.focus();
                return false;
            }
        }
    }
    
    return true;
}

// Auto-generate panel fields if number is already set
document.addEventListener('DOMContentLoaded', function() {
    const numberOfPanels = document.getElementById('numberOfPanels').value;
    if (numberOfPanels && numberOfPanels > 0) {
        generatePanelFields();
        
        // Pre-fill existing panel serial numbers if available
        <?php if(isset($client_data['number_of_panels']) && $client_data['number_of_panels'] > 0): ?>
            setTimeout(() => {
                <?php 
                $panelResult = $db->query("SELECT panel_number, serial_number FROM solar_panels WHERE client_id = " . ($client_data['id'] ?? 0));
                while($panel = $panelResult->fetch_assoc()): 
                ?>
                    const panelField = document.querySelector('[name="panel_serial_<?php echo $panel['panel_number']; ?>"]');
                    if (panelField) {
                        panelField.value = "<?php echo htmlspecialchars($panel['serial_number']); ?>";
                    }
                <?php endwhile; ?>
            }, 100);
        <?php endif; ?>
    }
});

// File size validation on change
document.querySelectorAll('input[type="file"]').forEach(input => {
    input.addEventListener('change', function() {
        const file = this.files[0];
        if (file && file.size > 5242880) {
            alert('File size exceeds 5MB limit. Please choose a smaller file.');
            this.value = '';
        }
    });
});
</script>