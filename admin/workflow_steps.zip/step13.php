<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 13: PM Suryaghar Redeem Status</h5>
    </div>
    <div class="card-body">
        <form id="step13Form">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">PM Suryaghar Subsidy Redeemed? <span class="text-danger">*</span></label>
                    <select class="form-select" name="pm_redeem_status" id="pmRedeemStatus" required onchange="toggleSubsidyFields()">
                        <option value="">-- Select --</option>
                        <option value="no" <?php echo ($client_data['pm_redeem_status'] ?? '') == 'no' ? 'selected' : ''; ?>>No</option>
                        <option value="yes" <?php echo ($client_data['pm_redeem_status'] ?? '') == 'yes' ? 'selected' : ''; ?>>Yes</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3" id="subsidyAmountField" style="display: none;">
                    <label class="form-label">Subsidy Amount (₹) <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" name="subsidy_amount" 
                           value="<?php echo htmlspecialchars($client_data['subsidy_amount'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3" id="subsidyDateField" style="display: none;">
                    <label class="form-label">Subsidy Redeem Date <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" name="subsidy_redeem_date" 
                           value="<?php echo htmlspecialchars($client_data['subsidy_redeem_date'] ?? ''); ?>">
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function toggleSubsidyFields() {
    const pmRedeemStatus = document.getElementById('pmRedeemStatus').value;
    const subsidyAmountField = document.getElementById('subsidyAmountField');
    const subsidyDateField = document.getElementById('subsidyDateField');
    
    if (pmRedeemStatus === 'yes') {
        subsidyAmountField.style.display = 'block';
        subsidyDateField.style.display = 'block';
        document.querySelector('input[name="subsidy_amount"]').required = true;
        document.querySelector('input[name="subsidy_redeem_date"]').required = true;
    } else {
        subsidyAmountField.style.display = 'none';
        subsidyDateField.style.display = 'none';
        document.querySelector('input[name="subsidy_amount"]').required = false;
        document.querySelector('input[name="subsidy_redeem_date"]').required = false;
        document.querySelector('input[name="subsidy_amount"]').value = '';
        document.querySelector('input[name="subsidy_redeem_date"]').value = '';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    const pmRedeemStatus = document.getElementById('pmRedeemStatus');
    if (pmRedeemStatus.value === 'yes') {
        toggleSubsidyFields();
    }
});
</script>