<div class="card">
    <div class="card-header">
        <h5 class="card-title">Step 12: Meter Installation Photo</h5>
    </div>
    <div class="card-body">
        <form id="step12Form" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Meter Installation Photo</label>
                    <input type="file" class="form-control" name="meter_installation_photo" accept="image/*">
                    <?php if(isset($client_data['meter_installation_photo'])): ?>
                        <small class="text-muted">Current: <?php echo htmlspecialchars($client_data['meter_installation_photo']); ?></small>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Meter Number</label>
                    <input type="text" class="form-control" name="meter_number" 
                           value="<?php echo htmlspecialchars($client_data['meter_number'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Installation Date</label>
                    <input type="date" class="form-control" name="meter_installation_date" 
                           value="<?php echo htmlspecialchars($client_data['meter_installation_date'] ?? ''); ?>">
                </div>
            </div>
        </form>
    </div>
</div>

<script>
function validateStep12() {
    // Photo upload is optional
    return true;
}
</script>