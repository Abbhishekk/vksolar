<!-- WhatsApp Button -->
    <a
      href="https://wa.me/919657135476"
      class="floating-btn whatsapp-btn"
      target="_blank"
      aria-label="Chat on WhatsApp"
    >
      <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Back to Top -->
    <a href="#" class="floating-btn back-to-top">
      <i class="bi bi-arrow-up"></i>
    </a>