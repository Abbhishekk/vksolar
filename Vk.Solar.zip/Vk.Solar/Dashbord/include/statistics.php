<div class="col-12">
            <div class="card mt-4">
              <div class="card-body">
                <h2>Statistics</h2>
                <p>Target you've set for each month</p>

                <div class="tabs">
                  <button class="tab active">Monthly</button>
                  <button class="tab">Quarterly</button>
                  <button class="tab">Annually</button>
                </div>

                <canvas id="myChart"></canvas>
              </div>
            </div>
          </div>